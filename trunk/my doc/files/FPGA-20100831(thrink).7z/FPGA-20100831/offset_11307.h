//---------------------------------------------------------------------------

#ifndef offset_11307H
#define offset_11307H
#include "offset.h"
//---------------------------------------------------------------------------
class offsetForm_11307:public AbstoffsetForm
{
        public:
                virtual TBit* SetChkBx();
                virtual TBit* SetCboBx();
                virtual TBit* SetScrollBar();
                virtual TBit2* SetScrollBar2();
                virtual TBit3* SetLblE3();
                virtual TBit4* SetLblE4();
                offsetForm_11307();
};


#endif

