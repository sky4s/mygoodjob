//-----------------------------------------------------------------------------
//      20100608 revise as include Address_type files
//-----------------------------------------------------------------------------

#include <math.h>
#include <stdlib.h>
#define Num_ASIC 4
#include "Address_type_1B.h"
#include "Address_type_2B.h"
#include "Address_type_3B.h"
#include "Address_type_4B.h"
#include "Address_type_1L.h"




