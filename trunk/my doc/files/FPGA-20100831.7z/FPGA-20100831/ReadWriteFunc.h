//---------------------------------------------------------------------------
//    20100608 Add function for USB sequential Read/ Write
//
//---------------------------------------------------------------------------
#ifndef ReadWriteFuncH
#define ReadWriteFuncH
#include "PrintPortI2C.h"
#include <HWINTERFACELib_TLB.h>
#include <HWINTERFACELib_OCX.h>
#include "USBHIDIOC.H"
#include "USB_I2C.h"
#include <stdio.h>
#include <stdlib.h>
#include <String.h>         
//---------------------------------------------------------------------------


class RW_Func{
        public:
                RW_Func();
                int LPT_Read_Byte(unsigned char dev_addr, unsigned char* data_addr,
                        int data_addr_cnt,unsigned char* data_read);
                int LPT_Write(unsigned char dev_addr, unsigned char* data_addr, int data_addr_cnt,
                        unsigned char* data_write, int data_len);
                int LPT_Read_seq(unsigned char dev_addr, unsigned char* data_addr, int data_addr_cnt,
                        unsigned char * data_read, int data_cnt);
                //bool USB_read(unsigned char dev_addr, unsigned char* data_addr, int data_addr_cnt,
                //        unsigned char* data_read, int data_len);
                bool USB_write(unsigned char dev_addr, unsigned char* data_addr, int data_addr_cnt,
                        unsigned char* data_write, int data_len);
                int LPT_Read_Byte_Skip_Ack(unsigned char dev_addr, unsigned char* data_addr,
                        int data_addr_cnt,unsigned char* data_read);

                int USB_connect(int pwr_i, int clck_i);
                int LPT_connect(void);
                bool USB_disconnect(void);
                bool USB_start();
                bool USB_stop();

                // 20100608 for USB sequential read/ write
                bool USB_seq_write_P1(unsigned char dev_addr, unsigned char* data_addr, int data_addr_cnt,
                 unsigned char* data_write, int data_len, bool overflag);
                bool USB_Data_Package(unsigned char* data_write, int data_len, bool overflag);
                bool USB_seq_read_P1(unsigned char dev_addr, unsigned char* data_addr, int data_addr_cnt,
                        unsigned char* data_read, int data_len, bool overflag);
                bool USB_r_Data_Package(unsigned char* data_read, int data_len, bool overflag);
};

extern CUsbhidioc USB;				// USB I/O function class
extern bool DeviceDetected;     // Check if System is active
extern unsigned int VendorID;    		// Uses Microchip's Vendor ID.
extern unsigned int ProductID;   		// UIB Board
#endif
