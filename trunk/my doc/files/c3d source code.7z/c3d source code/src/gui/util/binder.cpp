//#include <includeall.h>
#pragma hdrstop
#include "binder.h"

//C�t�Τ��
//#include <cstdarg>
//C++�t�Τ��
#include <utility>
//��L�w�Y���
//#include <boost/tokenizer.hpp>
//�����ؤ��Y���
//#include <debug.h>

namespace gui {
    namespace util {
	using namespace std;

	//=====================================================================
	// setter group
	//=====================================================================
	 Edit2ScrollBarSetter::Edit2ScrollBarSetter(TEdit * edit,
						    TScrollBar * scrollBar):edit(edit),
	    scrollBar(scrollBar) {
	};

	void Edit2ScrollBarSetter::set(TObject * sender) {
	    if (edit == sender) {
		int value = edit->Text.ToInt();
		 scrollBar->Position = value;
	    } else if (scrollBar == sender) {
		int value = scrollBar->Position;
		edit->Text = value;
	    }
	};

      ScrollBar2ScrollBarSetter::ScrollBar2ScrollBarSetter(TScrollBar * scrollBar1, TScrollBar * scrollBar2):scrollBar1(scrollBar1), scrollBar2(scrollBar2)
	{
	};

	void ScrollBar2ScrollBarSetter::set(TObject * sender) {
	    if (scrollBar1 == sender) {
		scrollBar2->Position = scrollBar1->Position;
	    } else if (scrollBar2 == sender) {
		scrollBar1->Position = scrollBar2->Position;
	    }
	};

      Edit2EditSetter::Edit2EditSetter(TEdit * edit1, TEdit * edit2):edit1(edit1), edit2(edit2)
	{
	};

	void Edit2EditSetter::set(TObject * sender) {
	    if (edit1 == sender) {
		edit2->Text = edit1->Text;
	    } else if (edit2 == sender) {
		edit1->Text = edit2->Text;
	    }
	};

	//=====================================================================

	//=====================================================================
	// binder group
	//=====================================================================
	MultiUIBinder::MultiUIBinder() {
	};
	void MultiUIBinder::active(TObject * sender) {
	    TWinControl *ctrl = dynamic_cast < TWinControl * >(sender);
	    if (null != ctrl) {
		Range range = setterMap.equal_range(ctrl);
		for (SetterItrator i = range.first; i != range.second; ++i) {
		    uiset_ptr setter = i->second;
		    setter->set(ctrl);
		}
	    }
	};
	void MultiUIBinder::bind(TEdit * edit, TScrollBar * scrollBar) {
	    uiset_ptr setter(new Edit2ScrollBarSetter(edit, scrollBar));
	    setterMap.insert(make_pair(edit, setter));
	    setterMap.insert(make_pair(scrollBar, setter));
	};
	void MultiUIBinder::bind(TEdit * edit1, TEdit * edit2) {
	    using namespace std;
	    uiset_ptr setter(new Edit2EditSetter(edit1, edit2));
	    setterMap.insert(make_pair(edit1, setter));
	    setterMap.insert(make_pair(edit2, setter));
	};
	void MultiUIBinder::bind(TScrollBar * scrollBar1, TScrollBar * scrollBar2) {
	    using namespace std;
	    uiset_ptr setter(new ScrollBar2ScrollBarSetter(scrollBar1, scrollBar2));
	    setterMap.insert(make_pair(scrollBar1, setter));
	    setterMap.insert(make_pair(scrollBar2, setter));
	};
	//=====================================================================
    };
};

