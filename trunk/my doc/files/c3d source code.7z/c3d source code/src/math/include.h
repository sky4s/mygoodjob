
#include "doubleArray.h"
#include "interpolation.h"
#include "regression.h"
#include "searcher.h"
#include "svd.h"
#include "gamma.h"
 