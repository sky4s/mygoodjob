// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// C++ TLBWRTR : $Revision:   1.151.1.0.1.27  $
// File generated on 2006/7/11 �U�� 08:47:59 from Type Library described below.

// ************************************************************************  //
// Type Lib: C:\WINDOWS\system32\hwinterface.ocx (1)
// LIBID: {BD6BB71B-5C9A-4FB3-877E-8B513D28B951}
// LCID: 0
// Helpfile: C:\WINDOWS\system32\hwinterface.hlp
// HelpString: hwinterface ActiveX Control module
// DepndLst: 
//   (1) v2.0 stdole, (C:\WINDOWS\system32\Stdole2.tlb)
// ************************************************************************ //

#include <vcl.h>
#pragma hdrstop

#include "HWINTERFACELib_TLB.h"

#if !defined(__PRAGMA_PACKAGE_SMART_INIT)
#define      __PRAGMA_PACKAGE_SMART_INIT
#pragma package(smart_init)
#endif

namespace Hwinterfacelib_tlb
{


// *********************************************************************//
// GUIDS declared in the TypeLibrary                                      
// *********************************************************************//
const GUID LIBID_HWINTERFACELib = {0xBD6BB71B, 0x5C9A, 0x4FB3,{ 0x87, 0x7E, 0x8B,0x51, 0x3D, 0x28,0xB9, 0x51} };
const GUID DIID__DHwinterface = {0x39F91450, 0x46FA, 0x41A9,{ 0x91, 0x0B, 0x66,0x27, 0x3D, 0x10,0x5E, 0xBB} };
const GUID DIID__DHwinterfaceEvents = {0xD7A782FE, 0xF757, 0x4C7C,{ 0x9A, 0x29, 0x8C,0xF0, 0x22, 0x76,0x0A, 0xD6} };
const GUID CLSID_Hwinterface = {0xB9022892, 0xEA92, 0x4F94,{ 0x81, 0x01, 0xB9,0xCD, 0xE3, 0x0E,0x66, 0x7D} };

};     // namespace Hwinterfacelib_tlb
