//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <conio.h>
#include <java/lang.h>
#include <cms/colorformat/excelfile.h>
#include <iostream>

//---------------------------------------------------------------------------

void excel()
{
    using namespace cms::colorformat;
    using namespace std;


    ExcelFileDB db("a.xls", Create);
    //�������s���ɮש��ɮפw�s�b
    bool newfile = true;

    if (newfile) {
	string_vector_ptr fieldsNames = ExcelFileDB::makec(2, "a", "b");
	db.createTable("tb", fieldsNames);

	db.insert(fieldsNames, ExcelFileDB::makec(2, "11", "22"));
	db.insert(fieldsNames, ExcelFileDB::makec(2, "33", "44"));
	db.insert(fieldsNames, ExcelFileDB::makec(2, "55", "66"));
    } else {
	db.setTableName("tb");
	bptr < DBQuery > query = db.selectAll();
	while (query->hasNext()) {
	    foreach(string & s, *query->nextResult()) {
		cout << s << " ";
	    }
	    cout << endl;
	};

	cout << *query->get(1, 1) << endl;
    };
}

void measureFile()
{
    using namespace cms::colorformat;
    using namespace std;

    const string & filename = "ramp.xls";
    ExcelFileDB db(filename, ReadOnly);
    db.setTableName("Sheet1");
    bptr < DBQuery > query = db.selectAll();
    while (query->hasNext()) {
	string_vector_ptr result = query->nextResult();
	double_vector_ptr doubleresult = query->toDoubleVector(result);
	foreach(const double d, *doubleresult) {
	    cout << d << " ";
	}
	cout << endl;
    };
}

#pragma argsused
int main(int argc, char *argv[])
{
    //excel();
    measureFile();
    getch();
    return 0;
}

//---------------------------------------------------------------------------

