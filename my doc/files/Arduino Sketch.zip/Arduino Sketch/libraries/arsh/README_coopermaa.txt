June 28, 2011
Coopermaa

This is the arsh library for the Arduino.

To install on Arduino 0018 or later, move this directory to
arduino sketch folder or arduino-00nn/libraries/arsh.

arsh was written by Bert Vermeulen.
http://biot.com/arsh/
