#ifndef EEPROM_H
#define EEPROM_H

#include <EEPROMex.h>

class BlockEEPROM {
  private:
  byte block;
  public:
  BlockEEPROM(byte block) {
    
  };
};



#endif
