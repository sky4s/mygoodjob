#ifndef KEYPAD_H
#define KEYPAD_H


class ResistorKeypad {
  private:
    byte keypadPin;
    byte keypressed;
    int keyboardValue ;  // value read from the keyboard
    unsigned long pressedTime;
    bool longPressSetup;
    boolean reflect;
#define INTERNAL_DELAY 50
#define LONG_PRESS_TIME 1000

  public:
    ResistorKeypad(byte keypadPin, boolean reflect): keypadPin(keypadPin), reflect(reflect) {
      keypressed = 0;
      keyboardValue = 0;
      longPressSetup = false;
    }

    void setReflect(boolean reflect) {
      this->reflect = reflect;
    }

    //read the keyboard routine
    byte readkeyboard() {
      keyboardValue = analogRead(MATRIX_KEYPAD_PIN); // read the value (0-1023)
      debugk("keyboardValue: " + String(keyboardValue));

      pressedTime = millis();
      if (keyboardValue < 67) {
        return KEY_NOTOUCH;
      }

      if ((keyboardValue >= 67) && (keyboardValue < 108)) {
        keypressed = 2;
        return KEY_NOTOUCH;
      }
      if ((keyboardValue >= 108) && (keyboardValue < 162)) {
        keypressed = 3;
        return KEY_NOTOUCH;
      }
      if ((keyboardValue >= 162) && (keyboardValue < 253)) {
        keypressed = 4;
        return KEY_NOTOUCH;
      }
      if ((keyboardValue >= 253) && (keyboardValue < 361)) {
        if (!reflect) {
          keypressed = KEY_KPL;
        } else {
          keypressed = KEY_GEAR;
        }
      }
      if ((keyboardValue >= 361) && (keyboardValue < 479)) {
        if (!reflect) {
          keypressed = KEY_GEAR;
        } else {
          keypressed = KEY_KPL;
        }
      }
      if ((keyboardValue >= 479) && (keyboardValue < 619)) {
        keypressed = 7;
        return KEY_NOTOUCH;
      }
      if ((keyboardValue >= 619) && (keyboardValue < 765)) {
        if (!reflect) {
          keypressed = KEY_PROGRESS;
        } else {
          keypressed = KEY_SPEED;
        }
      }
      if ((keyboardValue >= 765) && (keyboardValue < 819)) {
        if (!reflect) {
          keypressed = KEY_SPEED;
        } else {
          keypressed = KEY_PROGRESS;
        }
      }
      if ((keyboardValue >= 819) && (keyboardValue < 889)) {
        keypressed = 10;
        return KEY_NOTOUCH;
      }
      if ((keyboardValue >= 889) && (keyboardValue < 938)) {
        keypressed = 11;
        return KEY_NOTOUCH;
      }
      if (keyboardValue >= 938) {
        keypressed = KEY_MODE;
      }
      //  tmp=keyboardValue;
      //NOTE: the values used above are all halfway between the value obtained with each keypress in previous test sketch

      while (keyboardValue > 25/* && (millis()-pressedTime) <=LONG_PRESS_TIME*/) {
        //    debug("in debounce " + String(keyboardValue));
        delay (INTERNAL_DELAY);
        keyboardValue = analogRead(MATRIX_KEYPAD_PIN); // read the value (0-1023)

        // 按壓太久, 直接跳成SETUP
        if ( keyboardValue >= 938 && (millis() - pressedTime) > LONG_PRESS_TIME && KEY_MODE == keypressed) {
          longPressSetup = true;
          return KEY_SETUP;
        }
      }//wait until key no longer being pressed before continuing
      debugk("keypressed: " + String(keypressed));
      if (true == longPressSetup && KEY_MODE == keypressed) {
        longPressSetup = false;
        return KEY_SETUP_STOP;
      } else {
        return keypressed;
      }

    }
    //end of read the keyboard routine
};


#endif




