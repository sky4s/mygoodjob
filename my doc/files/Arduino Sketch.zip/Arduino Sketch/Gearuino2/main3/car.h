#ifndef CAR_H
#define CAR_H

//============================================================================
// Car define
//============================================================================
//#define LANCER_FORTIS
#define FIESTA

#ifdef LANCER_FORTIS
#define TireRound 2.049575047
static const float GearRatio[] = {
  10.71,
  14.37588,
  8.54964,
  6.57288,
  5.09184,
  3.86172,
  3.17016,
};
define MaxGear 7;
#endif

#ifdef FIESTA
#define CAR_WEIGHT 1140+42.8/2*0.74+60 //車重+油箱容量/2*密度+我的體重 = 1215
#define TireRound 1.8893538219
static const float GearRatio[] = {
  15.265971,//這一個虛擬檔位, 是為了容忍判斷誤差所設計
  15.256715,
  9.460955,
  6.250908,
  4.444413,
  3.376965,
  2.73429
};
#define MaxGear  7
#endif

#define AFR 14.7
//============================================================================

class Car {
  private:
    float gearrpm[MaxGear];
    float minDelta ;
    byte minIndex ;
  public:
    byte getGearPosition(int rpm, byte speed) {
      for (int x = 0; x < MaxGear; x++) {
        gearrpm[x] = speed * GearRatio[x] / TireRound * 1000 / 60;
      }
      minDelta = 3.4028235E+38;
      minIndex = 0;
      for (byte x = 1; x < MaxGear; x++) {
        float delta = abs( gearrpm[x] - rpm);
        if (delta < minDelta) {
          minDelta = delta;
          minIndex = x;
        }
      }

      return minIndex;
    }

    float getKPL(byte vss, float maf) {
      return 3.021639069337143 * vss / maf;
    }

    // km/h = 1000m/h = 1000m/3600s = 0.27777777777777777777777777777778 m/s = 1/3.6 m/s
#define KPH_TO_MPS 1/3.6
#define ONE_PS 75 //75kg-m/sec
    float getPS(short weight, byte speed) {
      float ps = ((float)weight) * speed * KPH_TO_MPS / ONE_PS;
      return ps;
    }

    float getTorque(float ps, int rpm) {
      return 716 * ps / rpm;
    }
};

#endif

