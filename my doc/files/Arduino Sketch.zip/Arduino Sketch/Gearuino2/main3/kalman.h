#ifndef KALMAN_H
#define KALMAN_H
//------------------------------------------------------------------
//Kalman Filter
//By Jed 2013/12/23
//www.xuan.idv.tw
//------------------------------------------------------------------
class Kalman {
  private:
  /*
   To specify Q, you need to know the motor model and connect it to possible physical disturbances. 
   Then approximate the noise sources with white Gaussian distribution.
   (模型本身的誤差?)
  
    Matrix R is much easy to ascertain, because the measurement equipment often has some error characteristics. 
    (量測造成的誤差)
  */
    float q, r;

  public:
    Kalman() {
      q = 0.0001, r = 0.05;
    }

    void setQ(float q) {
      this->q = q;
    }

    void setR(float r) {
      this->r = r;
    }

    float getQ() {
      return q;
    }

    float getR() {
      return r;
    }

    float filter(float inData)
    {
      static float prevData = 0;
      static float p = 10, kGain = 0;

      //Kalman filter function start*******************************
      p = p + q;
      kGain = p / (p + r);

      inData = prevData + (kGain * (inData - prevData));

      p = (1 - kGain) * p;

      prevData = inData;
      //Kalman filter function stop********************************

      return inData;
    }
};

//------------------------------------------------------------------
#endif
