#ifndef CONFIG_H
#define CONFIG_H


/*
Normal mode: G/K/P/S
 Boost mode: null
 Sport mode: G/K/P/S
 */
//=======================================================
// keypad index的相關define
//=======================================================
#define MODE_SIZE 3 //normal / boost / sports
#define PART_SIZE 4
/* Gear
0:gear
1:rpm
2:Fuel System Status
3:None
*/
#define INDEX_G 0
#define G_GEAR 0
#define G_RPM 1
#define G_FUEL 2
#define G_NONE 3

/* KPL
0:throttle
1:oil(kpl)
2:ECU voltage(v1)
3:OBD voltage(v2)
4:intake temperature
5:coolant temperature
6:relative throttle
7.ps (horsepower)
8.torque
9:None
*/
#define INDEX_K 1
#define K_THROTTLE 0
#define K_KPL 1
#define K_ECU_V 2
#define K_OBD_V 3
#define K_INTAKE 4
#define K_COOLANT 5
#define K_R_THROTTLE 6
//#define K_PS 7
//#define K_TORQUE 8
#define K_NONE 7

/* Progress
0:throttle
1:oil(kpl)
2:rpm
3:relative throttle
4:None
*/
#define INDEX_P 2
#define P_THROTTLE 0
#define P_KPL 1
#define P_RPM 2
#define P_R_THROTTLE 3
#define P_NONE 4


/* Speed
*/
#define INDEX_S 3
static byte GKPSSize[PART_SIZE] = {4, 10, 5, 0};
//=======================================================

//=======================================================
// speed fix
//=======================================================
#define SPEED_FIX_SIZE 29
#define SPEEDL_LIMIT_MAX 150
#define SPEEDL_LIMIT_MIN 90
#define IN_ARRAY 0
#define OUT_ARRAY 1
//=======================================================

//=======================================================
//default GKPS setting
//=======================================================
static byte DefaultGKPSArray[MODE_SIZE][PART_SIZE] = {
  { 0, 1, 1 , 0 },
  {  } ,
  { 1, 5, 2 , 0 }
};
//預設setup的設定
#define SET_REFLECT 0
#define SET_ELM_LOOP_IDLE 1
#define SET_DEBUG_OUTPUT 2
#define SET_MSG_OUTPUT 3
#define SET_SPEED_LIMIT 4
#define SET_SPEED_TH 5
//#define SET_SPEED_FIX 6
//#define SET_SPEED_FIX_TRAIN 7
#define SET_CAR_WEIGHT 6
#define SETUP_SIZE 7



//#define SET_KALMAN_Q
//#define SET_KALMAN_R
//static byte DefaultSetupArray[SETUP_SIZE] = {1, 0, debugOutput, true, 1, 121, 1, 0};
//=======================================================
struct Configure {
  public:
    boolean reflect;
    byte elmLoopIdleTime;
    boolean debugOutput;
    boolean messageOutput;
    boolean speedLimit;
    byte speedThreshold;
//    boolean speedFix;
//    boolean speedFixTrain;
    short carWeight;

  private:
    void initDefault() {
      reflect = true;
      elmLoopIdleTime = 0;
      this->debugOutput = debugOutput;
      messageOutput = true;
      speedLimit = true;
      speedThreshold = 121;
//      speedFix = true;
//      speedFixTrain = false;
      carWeight = CAR_WEIGHT;

      for (int x = 0; x < PART_SIZE; x++) {
        GKPSArray[0][x] = DefaultGKPSArray[0][x] ;
        GKPSArray[2][x] = DefaultGKPSArray[2][x] ;
      }

//      for (int x = 0; x < SETUP_SIZE; x++) {
//        setupArray[x] = DefaultSetupArray[x];
//      }

//      for (int x = 0; x < 4; x++) {
//        speedFixArray[IN_ARRAY][x] = x * 10;
//        speedFixArray[OUT_ARRAY][x] = x * 10;
//      }
//      for (int x = 4; x < 23; x++) {
//        speedFixArray[IN_ARRAY][x] = 5 * (4 + x);
//        speedFixArray[OUT_ARRAY][x] = 5 * (4 + x);
//      }
//      for (int x = 23; x < SPEED_FIX_SIZE; x++) {
//        speedFixArray[IN_ARRAY][x] = 150 + (x - 23) * 20;
//        speedFixArray[OUT_ARRAY][x] = 150 + (x - 23) * 20;
//      }
    }

  public:
    Configure() {
      initDefault();
    }
    byte GKPSArray[MODE_SIZE][PART_SIZE] ;
    /*
    0	0,    1	10,    2	20,    3	30,    4	40,    5	45,    6	50,    7	55,    8	60,    9	65,    10	 70,    11 	75,
    12 	80,    13 	85,    14	 90,    15	95,    16	 100,    17	105,    18	110,    19	115,    20	120,
    21	125,    22	130,    23	150,    24	170,    25	190,    26	210,    27	230,    28	250
    */
//    byte speedFixArray[2][SPEED_FIX_SIZE];
//    byte setupArray[SETUP_SIZE];
};
//=======================================================

//Configure c;
#define ELM_LOOP_IDLE c.elmLoopIdleTime * 10
#define IS_SPEED_FIX c.speedFix
#define IS_SPEED_FIX_TRAIN c.speedFixTrain
#define SPEED_TH c.speedThreshold

static byte v;
#define pushButton(index) v = c.GKPSArray[modeIndex][index]; \
  v++; v = (v >= GKPSSize[index] ) ? 0 : v;\
  c.GKPSArray[modeIndex][index] = v;
//=======================================================
#endif
