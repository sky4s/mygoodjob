#ifndef DEBUG_H
#define DEBUG_H

boolean debugOutput = true;
#ifdef DEBUG
#define debug(s)  if(debugOutput) {  Serial.println(s); } else { }
#else
#define debug(s)
#endif
#ifdef DEBUG_L1
#define debug1(s)  if(debugOutput) {  Serial.println(s); } else { }
#else
#define debug1(s)
#endif
#ifdef DEBUG_K
#define debugk(s)  if(debugOutput) {  Serial.println(s); } else { }
#else
#define debugk(s)
#endif

#ifdef VERBOSE
#define verbose(s) Serial.println(s)
#else
#define verbose(s)
#endif

#ifdef BRIDGE

boolean hc05BaudRate = false;
int brideMode = 0;
boolean localecho = true;

void bridge() {
  if (Serial.available()) {
    char in = Serial.read();
    if (localecho) {
      Serial.write(in);
    }

    if ( in == '$') {
      brideMode++;
      brideMode = brideMode >= 3 ? 0 : brideMode;
      if (0 == brideMode) {
        Serial.println("Change to ELM");
        softserial.listen();
      } else if (1 == brideMode) {
        Serial.println("Change to BT");
        softserialBT.listen();
      } else if (2 == brideMode) {
        Serial.println("Change to Serial");
      }
    }
    else if ( in == '%') {
      hc05BaudRate = !hc05BaudRate;
      if (hc05BaudRate) {
        softserialBT.begin(38400);
        Serial.println("Change BT to 38400bps");
      }
      else {
        softserialBT.begin(9600);
        Serial.println("Change BT to 9600bps");
      }
    }
    else if ( in == '#') {
      localecho = !localecho;
      Serial.println("LocalEcho " + String( (localecho ? "ON" : "OFF")));
    }
    else {
      if (0 == brideMode) {
        softserial.print(in);
      } else   if (1 == brideMode) {
        softserialBT.print(in);
      } else   if (2 == brideMode) {
      }
    }
  }

  if (0 == brideMode) {
    if (softserial.available()) {
      Serial.write(softserial.read());
    }
  } else   if (1 == brideMode) {
    if (softserialBT.available()) {
      Serial.write(softserialBT.read());
    }
  } else   if (2 == brideMode) {
  }

}
#endif

#endif
