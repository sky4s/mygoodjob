#ifndef LED_H
#define LED_H

//#define LED_ON_GLASS

//===================================================================
// setting
//===================================================================
#ifdef LED_ON_GLASS
boolean ledReflect = true;
boolean upsidedownMode = false;
#else
boolean ledReflect = true;
boolean upsidedownMode = true;
#endif

boolean commonAnodeLED = false;

//===================================================================

/*
 Now we need a LedControl to work with.
 ***** These pin numbers will probably not work with your hardware *****
 pin 12 is connected to the DataIn e
 pin 11 is connected to the CLK
 pin 10 is connected to LOAD
 We have only a single MAX72XX.
 */
//LedControl lc=LedControl(12,11,10,1,commonAnodeLED,false,!ledReflect);
LedControl lc = LedControl(LED_DATA_PIN, LED_CLK_PIN, LED_LOAD_PIN, 2, commonAnodeLED, ledReflect, upsidedownMode);

void initLedControl() {
  /*
   The MAX72XX is in power-sav  ing mode on startup,
   we have to do a wakeup call
   */
  lc.shutdown(0, false);
  /* Set the brightness to a medium values */
  lc.setIntensity(0, 15);
  /* and clear the display */
  lc.clearDisplay(0);
  lc.setScanLimit(0, 4);

  lc.shutdown(1, false);
  /* Set the brightness to a medium values */
  lc.setIntensity(1, 15);
  /* and clear the display */
  lc.clearDisplay(1);
  lc.setScanLimit(1, 4);
}

void setBoostMode(boolean boost) {
  if (boost) {
    lc.setScanLimit(0, 1);
    lc.setScanLimit(1, 0);
  }
  else {
    lc.setScanLimit(0, 4);
    lc.setScanLimit(1, 4);
  }
}


void displayGear(byte gear) {
  lc.setDigit(0, 2, gear, false);
}

void clearGear() {
  lc.setChar(0, 2, 32, false);
}

void displayGear(int rpm) {
  if (rpm < 1000) {
    int digit = rpm / 100;
    lc.setDigit(0, 2, digit, true);
  }
  else {
    int digit = rpm / 1000;
    lc.setDigit(0, 2, digit, false);
  }
}

void displayGear(char c) {
  lc.setChar(0, 2, c, false);
}
void displayGear(char c, boolean dp) {
  lc.setChar(0, 2, c, dp);
}

void displaySpeed(char c0, char c1, char c2) {
  lc.setChar(0, 1, c2, false);
  lc.setChar(0, 0, c1, false);
  lc.setChar(1, 0, c0, false);
}

void displaySpeed(byte speed) {
  int digit0 = speed % 10;
  int digit10 = (speed / 10) % 10;
  int digit100 = (speed / 100) % 10;
  if (speed >= 100) {
    lc.setDigit(1, 0, digit100, false);
  }
  else {
    lc.setChar(1, 0, 32, false);
  }
  if (speed >= 10) {
    lc.setDigit(0, 0, digit10, false);
  }
  else {
    lc.setChar(0, 0, 32, false);
  }
  lc.setDigit(0, 1, digit0, false);
}

void clearSpeed() {
  lc.setChar(0, 1, 32, false);
  lc.setChar(0, 0, 32, false);
  lc.setChar(1, 0, 32, false);
}

void displayKPL(char c0, char c1, char c2) {
  lc.setChar(0, 3, c2, false);
  lc.setChar(0, 4, c1, false);
  lc.setChar(1, 1, c0, false);
}


boolean isFloating(float value) {
  return  ((int)value ) == value;
}

void displayKPL(float kpl) {
  int ikpl = (kpl * 10);

  int digit0 = ikpl % 10;
  int digit10 = (ikpl / 10) % 10;
  int digit100 = (ikpl / 100) % 10;
  if (ikpl >= 100) {
    lc.setDigit(1, 1, digit100, false);
  } else {
    lc.setChar(1, 1, 32, false);
  }
  lc.setDigit(0, 4, digit10, false);
  lc.setDigit(0, 3, digit0, true);

}

void clearKPL() {
  lc.setChar(0, 3, ' ', false);
  lc.setChar(0, 4, ' ', false);
  lc.setChar(1, 1, ' ', false);
}

void displayKPL(int kpl) {
  boolean negative = kpl < 0;
  kpl = negative ? -kpl : kpl;

  int digit0 = kpl % 10;
  int digit10 = (kpl / 10) % 10;
  int digit100 = (kpl / 100) % 10;
  if (kpl >= 100) {
    lc.setDigit(1, 1, digit100, false);
  } else {
    lc.setChar(1, 1, 32, false);
  }
  if (kpl >= 10) {
    lc.setDigit(0, 4, digit10, false);
  }
  else {
    lc.setChar(0, 4, 32, false);
  }
  lc.setDigit(0, 3, digit0, false);

  if (negative) {
    if (kpl >= 10) {
      lc.setChar(1, 1, '-', false);
    } else {
      lc.setChar(0, 4, '-', false);
    }
  }
}

void clearProgress() {
  lc.setRow(1, 2, 0);
  lc.setRow(1, 3, 0);
  lc.setRow(1, 4, 0);
}

void setProgress(byte index, boolean state) {
  index = 19 - index;
  if (index >= 0 && index < 8) {
    lc.setLed(1, 2, index, state);
  } else if ( index >= 8 && index < 16) {
    lc.setLed(1, 3, 15 - index, state);
  } else if ( index >= 16 && index < 20) {
    lc.setLed(1, 4, index - 16, state);
  }
}

void fullProgress(byte index) {
  for (int x = 0; x <= index; x++) {
    setProgress(x, true);
  }
  for (int x = index + 1; x < 20; x++) {
    setProgress(x, false);
  }
}

int progressindex0 = 0;
void moveProgress() {
  clearProgress();
  setProgress(progressindex0, true);
  progressindex0++;
  if ( progressindex0 >= 20) {
    progressindex0 = 0;
  }
}

void fullProgress(byte value, byte min, byte max) {
  if ( value == min) {
    clearProgress();
  } else {
    byte index = (byte)( ((double)value - min) / (max - min) * 20 - 1);
    index = index < 0 ? 0 : index;
    fullProgress(index);
  }
}

#define ERROR_STRING_DELAY 1000
void showErrorMessage(char c0, char c1, char c2, char c3, char c4, char c5) {
  displaySpeed(c0, c1, c2);
  displayKPL(c3, c4, c5);
  delay(ERROR_STRING_DELAY);
  clearSpeed();
  clearKPL();
  delay(ERROR_STRING_DELAY);
}

//int progressIndex1 = 0;
//void increaseProgress(byte index) {
//  for (progressIndex = progressIndex + 1; progressIndex <= index; progressIndex++) {
//    setProgress(progressIndex, true);
//  }
//}
//void decreaseProgree(byte index) {
//  for (progressIndex = progressIndex; progressIndex >= index; progressIndex--) {
//    setProgress(progressIndex, false);
//  }
//}

void setLEDPowerSaving(boolean powerSaving) {
  lc.shutdown(0, powerSaving);
  lc.shutdown(1, powerSaving);
}

#endif

