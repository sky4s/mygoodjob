#ifndef KEYPAD_H
#define KEYPAD_H


byte keypressed = 0;
//int keyboardPin = 3;    // Analog input pin that the keypad is attached to
int keyboardValue = 0;   // value read from the keyboard
unsigned long pressedTime;
bool longPressSetup = false;
#define INTERNAL_DELAY 50
#define LONG_PRESS_TIME 1000


//read the keyboard routine
byte readkeyboard() {
  //  longPress = false;
  keyboardValue = analogRead(MATRIX_KEYPAD_PIN); // read the value (0-1023)

#ifdef DEBUG
  if (keyboardValue > 67) {
    Serial.println("analogRead: " + String(keyboardValue));
  }
#endif
  pressedTime = millis();
  if (keyboardValue < 67) {
    return -1;
  }

  if ((keyboardValue >= 67) && (keyboardValue < 108)) {
    keypressed = 2;
  }
  if ((keyboardValue >= 108) && (keyboardValue < 162)) {
    keypressed = 3;
  }
  if ((keyboardValue >= 162) && (keyboardValue < 253)) {
    keypressed = 4;
  }
  if ((keyboardValue >= 253) && (keyboardValue < 361)) {
    keypressed = KEY_KPL;
  }
  if ((keyboardValue >= 361) && (keyboardValue < 479)) {
    keypressed = KEY_GEAR;
  }
  if ((keyboardValue >= 479) && (keyboardValue < 619)) {
    keypressed = 7;
  }
  if ((keyboardValue >= 619) && (keyboardValue < 765)) {
    keypressed = KEY_PROGRESS;
  }
  if ((keyboardValue >= 765) && (keyboardValue < 819)) {
    keypressed = KEY_SPEED;
  }
  if ((keyboardValue >= 819) && (keyboardValue < 889)) {
    keypressed = 10;
  }
  if ((keyboardValue >= 889) && (keyboardValue < 938)) {
    keypressed = 11;
  }
  if (keyboardValue >= 938) {
    keypressed = KEY_MODE;
  }
  //  tmp=keyboardValue;
  //NOTE: the values used above are all halfway between the value obtained with each keypress in previous test sketch

  while (keyboardValue > 25/* && (millis()-pressedTime) <=LONG_PRESS_TIME*/) {
    delay (INTERNAL_DELAY);
    keyboardValue = analogRead(MATRIX_KEYPAD_PIN); // read the value (0-1023)

    // 按壓太久, 直接跳成SETUP
    if ( keyboardValue >= 938 && (millis() - pressedTime) > LONG_PRESS_TIME && KEY_MODE == keypressed) {
      longPressSetup = true;
      return KEY_SETUP;
    }
  }//wait until key no longer being pressed before continuing

  if (true == longPressSetup && KEY_MODE == keypressed) {
    longPressSetup = false;
    return KEY_SETUP_STOP;
  } else {
    return keypressed;
  }

  //  if ( (millis() - pressedTime) > LONG_PRESS_TIME && KEY_MODE == keypressed ) {
  //    return KEY_SETUP_STOP;
  //  }
  //  else {
  //    return keypressed;
  //  }
}
//end of read the keyboard routine


//#ifdef USE_BUTTON
//#define MAX_FUNC_COUNT 5
//void processButton(Bounce &bouncer) {
//  if (bouncer.update() == true && bouncer.read() == HIGH) {
//    switch (bouncer.pin) {
//      case SwitchPin:
//        funcselect++;
//        funcselect = (MAX_FUNC_COUNT == funcselect) ? 0 : funcselect;
//        break;
//      case ReflectPin:
//        ledReflect = !ledReflect;
//        break;
//    }
//    digitalWrite(LEDPin, HIGH);
//    delay(32);
//    digitalWrite(LEDPin, LOW);
//  }
//}
//#endif

#endif




