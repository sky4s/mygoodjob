#ifndef DEBUG_H
#define DEBUG_H

//#ifdef ITERACTION
//void interaction() {
//  if (serialBuffer.listen()) {
//    String line = serialBuffer.getLine();
//    hc05.sendCommand(line);
//  }
//  if (hc05.isResponse()) {
//    if (hc05.isResponseOk()) {
//      String*vec = hc05.getResponses();
//      int size = hc05.getResponseSize();
//      if (size == 0) {
//        Serial.println("Ok");
//      }
//      for (int x = 0; x < size; x++) {
//        String s = vec[x];
//        Serial.println(s);
//      }
//    }
//    else {
//      Serial.println("? " + hc05.getResponses()[0]);
//    }
//  }
//}
//#endif

#ifdef BRIDGE

boolean hc05BaudRate = false;
int brideMode = 0;
boolean localecho = true;

void bridge() {
  if (Serial.available()) {
    char in = Serial.read();
    if (localecho) {
      Serial.write(in);
    }

    if ( in == '$') {
      brideMode++;
      brideMode = brideMode >= 3 ? 0 : brideMode;
      if (0 == brideMode) {
        Serial.println("Change to ELM");
        softserial.listen();
      } else if (1 == brideMode) {
        Serial.println("Change to BT");
        softserialBT.listen();
      } else if (2 == brideMode) {
        Serial.println("Change to Serial");
      }
    }
    else if ( in == '%') {
      hc05BaudRate = !hc05BaudRate;
      if (hc05BaudRate) {
        softserialBT.begin(38400);
        Serial.println("Change BT to 38400bps");
      }
      else {
        softserialBT.begin(9600);
        Serial.println("Change BT to 9600bps");
      }
    }
    else if ( in == '#') {
      localecho = !localecho;
      Serial.println("LocalEcho " + String( (localecho ? "ON" : "OFF")));
    }
    else {
      if (0 == brideMode) {
        softserial.print(in);
      } else   if (1 == brideMode) {
        softserialBT.print(in);
      } else   if (2 == brideMode) {
      }
    }
  }

  if (0 == brideMode) {
    if (softserial.available()) {
      Serial.write(softserial.read());
    }
  } else   if (1 == brideMode) {
    if (softserialBT.available()) {
      Serial.write(softserialBT.read());
    }
  } else   if (2 == brideMode) {
  }

  //#ifdef USE_BT_PROXY
  //  if (hc05Proxy) {
  //    if (softserialBT.available()) {
  //      Serial.write(softserialBT.read());
  //    }
  //  } else {
  //    if (softserial.available()) {
  //      Serial.write(softserial.read());
  //    }
  //  }
  //#else
  //  if (softserial.available()) {
  //    Serial.write(softserial.read());
  //  }
  //#endif

  //  if (softserial.available()) {
  //    Serial.write(softserial.read());
  //  }
}
#endif

#endif
